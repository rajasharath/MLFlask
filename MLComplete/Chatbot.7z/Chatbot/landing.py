from generatengrams import ngrammatch

ngrammatch('Mobile')

#ngrammatch('Restaurant')